# TONY — proyecto Android inicial

Interfaz azul oscuro, reconocimiento de voz en español (es-PE), respuesta hablada y comandos básicos de Android.

## Importante: estado real de esta entrega
Este paquete contiene el **código fuente de un proyecto Android Studio**, no un APK compilado. El entorno de creación no dispone del Android SDK/Gradle para compilar y firmar un APK aquí.

## Cómo generar el APK
1. Instala Android Studio en una computadora.
2. Abre la carpeta `TONY_Android_Project` con **Open**.
3. Espera a que Gradle sincronice el proyecto e instala el SDK Android 35 si Android Studio lo solicita.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio generará el APK de depuración en `app/build/outputs/apk/debug/app-debug.apk`.
6. Pasa el APK a tu Android e instálalo. Permite el acceso al micrófono cuando la aplicación lo solicite.

## Qué funciona en esta primera versión
- Pantalla de bienvenida de TONY con diseño azul.
- Reconocimiento de voz al tocar el botón.
- Respuestas habladas mediante el motor de texto a voz del teléfono.
- Consulta de hora.
- Apertura de Google Maps y búsquedas web.
- Marcador telefónico con confirmación del usuario (no llama automáticamente).

## Qué todavía no está implementado
- **Activación manos libres continua «Hola, Tony»**: Android limita el uso permanente del micrófono en segundo plano. Para hacerlo de forma fiable se necesita un servicio de primer plano visible, permisos y pruebas específicas del dispositivo; el reconocimiento de voz estándar de esta demo solo escucha después de pulsar el botón.
- **Conversación de IA avanzada**: necesita conectar un servicio de IA mediante un backend seguro. No se debe incrustar una clave privada de API dentro del APK.
- Envío/lectura de WhatsApp, SMS y correo, control de música y alarmas: requieren integraciones y permisos adicionales.

## Requisitos
- Android Studio con JDK 17.
- Android 8.0 o posterior (minSdk 26).
- Micrófono y servicio de reconocimiento de voz disponible.
