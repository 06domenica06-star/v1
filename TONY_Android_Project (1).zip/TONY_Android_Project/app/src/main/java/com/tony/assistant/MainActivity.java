package com.tony.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status, answer;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean listening = false;
    private static final int REQ_AUDIO = 44;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF101D32);
        getWindow().setNavigationBarColor(0xFF101D32);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("es", "PE"));
        });
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        else prepareRecognizer();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 40, 28, 24);
        root.setBackgroundColor(0xFF101D32);

        TextView brand = new TextView(this);
        brand.setText("TONY");
        brand.setTextColor(0xFF8FC5FF);
        brand.setTextSize(18);
        brand.setLetterSpacing(.22f);
        root.addView(brand);

        TextView title = new TextView(this);
        title.setText("Hola, soy Tony");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = 38;
        root.addView(title, tp);

        TextView sub = new TextView(this);
        sub.setText("Tu asistente de voz para Android");
        sub.setTextColor(0xFFB8CBE2);
        sub.setTextSize(15);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        Button mic = new Button(this);
        mic.setText("🎙  HABLAR CON TONY");
        mic.setTextSize(16);
        mic.setAllCaps(false);
        mic.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF2878D0));
        mic.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, 64);
        mp.topMargin = 42;
        root.addView(mic, mp);
        mic.setOnClickListener(v -> startListening());

        status = new TextView(this);
        status.setText("Pulsa el micrófono y di: «Hola, Tony»");
        status.setTextColor(0xFF8FC5FF);
        status.setGravity(Gravity.CENTER);
        status.setTextSize(14);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 22;
        root.addView(status, sp);

        answer = new TextView(this);
        answer.setText("Estoy listo para ayudarte.");
        answer.setTextColor(0xFFFFFFFF);
        answer.setTextSize(17);
        answer.setGravity(Gravity.CENTER);
        answer.setPadding(18, 24, 18, 24);
        answer.setBackgroundColor(0xFF1A2D49);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = 28;
        root.addView(answer, ap);

        TextView examples = new TextView(this);
        examples.setText("PRUEBA DECIR\n\n«Tony, ¿qué hora es?»\n«Tony, busca cafeterías cerca»\n«Tony, abre Google Maps»\n«Tony, llama al 999 999 999»\n«Tony, busca cómo hacer yogurt»");
        examples.setTextColor(0xFFB8CBE2);
        examples.setTextSize(14);
        examples.setGravity(Gravity.CENTER);
        examples.setPadding(12, 26, 12, 0);
        root.addView(examples);

        setContentView(root);
    }

    private void prepareRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Este Android no tiene un servicio de reconocimiento de voz disponible.");
            return;
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            public void onReadyForSpeech(Bundle params) { status.setText("Te escucho…"); }
            public void onBeginningOfSpeech() { listening = true; }
            public void onRmsChanged(float rms) {}
            public void onBufferReceived(byte[] buffer) {}
            public void onEndOfSpeech() { listening = false; status.setText("Procesando…"); }
            public void onError(int error) { listening = false; status.setText("No te escuché. Pulsa para intentarlo otra vez."); }
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) handleCommand(matches.get(0));
            }
            public void onPartialResults(Bundle partialResults) {}
            public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return;
        }
        if (recognizer == null) prepareRecognizer();
        if (recognizer == null) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Dile algo a Tony");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(i);
    }

    private void handleCommand(String raw) {
        String q = raw.toLowerCase(Locale.ROOT);
        status.setText("Escuché: " + raw);
        if (q.contains("hola tony")) {
            speak("Hola. Estoy aquí. ¿Qué necesitas?");
        } else if (q.contains("hora")) {
            String now = new java.text.SimpleDateFormat("h:mm a", new Locale("es", "PE")).format(new java.util.Date());
            speak("Son las " + now);
        } else if (q.contains("mapa") || q.contains("cómo llegar") || q.contains("indicaciones")) {
            openUrl("geo:0,0?q=" + Uri.encode(raw));
            respond("Abriendo Google Maps.");
        } else if (q.contains("busca") || q.contains("buscar") || q.contains("qué es") || q.contains("como") || q.contains("cómo")) {
            openUrl("https://www.google.com/search?q=" + Uri.encode(raw));
            respond("Estoy buscando esa información en Internet.");
        } else if (q.startsWith("llama") || q.contains("llamar")) {
            String number = raw.replaceAll("[^0-9+]", "");
            if (number.length() >= 7) {
                Intent call = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
                startActivity(call);
                respond("Abrí el marcador para que confirmes la llamada.");
            } else respond("Dime el número de teléfono después de decir llama.");
        } else if (q.contains("abre youtube")) {
            openUrl("https://www.youtube.com");
            respond("Abriendo YouTube.");
        } else {
            speak("Todavía no tengo una respuesta inteligente conectada. Puedo buscarlo en Internet si dices busca y tu pregunta.");
        }
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { respond("No pude abrir esa aplicación."); }
    }
    private void respond(String s) { answer.setText(s); speak(s); }
    private void speak(String s) { answer.setText(s); if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "tony"); }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ_AUDIO && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) prepareRecognizer();
        else if (r == REQ_AUDIO) status.setText("Necesito permiso de micrófono para escucharte.");
    }
    @Override protected void onDestroy() {
        if (recognizer != null) { recognizer.destroy(); recognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
